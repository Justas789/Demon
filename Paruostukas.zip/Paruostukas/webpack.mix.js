let mix = require('laravel-mix')

mix.js('source/app.js','public')
.sass('source/scss/style.scss','css')
.setPublicPath('public')